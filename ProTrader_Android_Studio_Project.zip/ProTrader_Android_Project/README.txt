PRO TRADER - ANDROID STUDIO PROJECT

This is an Android WebView wrapper for your uploaded Paper-trading.html.

WHAT IS INCLUDED
- App label: Pro Trader
- Default Android launcher icon
- Local HTML app stored inside the APK
- JavaScript and WebView DOM storage enabled
- Internet permission for the existing live market connections
- No login and no separate backend/server

LOCAL DATA
Your HTML currently uses browser localStorage for app data. WebView DOM storage is enabled so this data is stored locally in the app's WebView profile on this phone. Do not uninstall/clear app data unless you have exported/backed up any important trades, because local data may be erased.

BUILD APK
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. Android Studio > Open > select the extracted ProTrader folder.
4. Wait for Gradle Sync. If prompted, install Android SDK Platform 35 and a compatible JDK (Android Studio's bundled JDK is suitable).
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio will show the generated APK location.

IMPORTANT
- This ZIP is the Android Studio source project, NOT a compiled APK.
- The current environment does not have the Android SDK/Gradle build environment needed to compile and sign an APK.
- Live prices/news require internet access and the external services used by the HTML to remain available.
- When the app is closed, Android suspends/stops its WebView activity; it does not run a continuously hosted backend.
